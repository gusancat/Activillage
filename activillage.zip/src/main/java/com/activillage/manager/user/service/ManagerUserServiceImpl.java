package com.activillage.manager.user.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.manager.user.dao.ManagerUserDao;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.user.book.dao.BookDao;
import com.activillage.user.book.vo.BookVO;
import com.activillage.user.join.vo.UserJoinVO;

@Service
@Transactional
public class ManagerUserServiceImpl implements ManagerUserService {
	
	@Autowired
	private ManagerUserDao managerUserDao;
	
	@Autowired
	private BookDao bookDao;
	@Qualifier("bookDao")
	

	@Override
	public List<UserJoinVO> userList(UserJoinVO uvo) {
		List<UserJoinVO> uList = null;
		uList = managerUserDao.userList(uvo);
		return uList;
	}

	@Override
	public int userWithdrawal(String u_email) {
		int result = 0;
		try {
			List<BookVO> list = bookDao.userBookConfirm(u_email);
			if (list.isEmpty()) {
				result = managerUserDao.userWithdrawal(u_email);
			} else {
				result = 2;
			}
		} catch (Exception e) {
			e.printStackTrace();
			result = 2;
		}
		System.err.println("사업자 탈퇴 서비스 result:" + result);
		return result;
	}

	@Override
	public int userListCnt(UserJoinVO uvo) {
		return managerUserDao.userListCnt(uvo);
	}

	@Override
	public Map<String, Integer> userAgeList() {
		Map<String, Integer> ageList = null;
		ageList = managerUserDao.userAgeList();
		return ageList;
	}

	@Override
	public List<BookVO> managerBookList(BookVO bvo) {
		List<BookVO> bList = null;
		bList = bookDao.managerBookList(bvo);
		return bList;
	}

	@Override
	public int managerBookListCnt(BookVO bvo) {
		// TODO Auto-generated method stub
		return bookDao.managerBookListCnt(bvo);
	}

}
