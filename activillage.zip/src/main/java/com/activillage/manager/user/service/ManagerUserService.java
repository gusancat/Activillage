package com.activillage.manager.user.service;

import java.util.List;
import java.util.Map;
import com.activillage.user.book.vo.BookVO;
import com.activillage.user.join.vo.UserJoinVO;

public interface ManagerUserService {
	public List<UserJoinVO> userList(UserJoinVO uvo);

	public int userWithdrawal(String u_email);

	public int userListCnt(UserJoinVO uvo);
	
	public Map<String, Integer> userAgeList();
	
	/*예약현황*/
	
	public List<BookVO> managerBookList(BookVO bvo);
	
	public int managerBookListCnt(BookVO bvo);
}
