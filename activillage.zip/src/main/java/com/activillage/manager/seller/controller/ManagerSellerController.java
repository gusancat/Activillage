package com.activillage.manager.seller.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.mail.internet.MimeMessage;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.activillage.common.graph.ChartMake;
import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.manager.sales.vo.SalesVO;
import com.activillage.manager.seller.service.ManagerSellerService;
import com.activillage.seller.join.vo.SellerJoinVO;
import com.activillage.user.book.vo.BookVO;

import lombok.extern.java.Log;

@Log
@Controller
@RequestMapping(value = "/manager")
public class ManagerSellerController {

	@Autowired
	private ManagerSellerService managerSellerService;

	@Autowired
	private JavaMailSender mailSender;

	@RequestMapping(value = "/main/sellerManage", method = RequestMethod.GET)
	public String sellerManage(@ModelAttribute SellerJoinVO svo, Model model, HttpSession session) {
		log.info("manager sellerManage 호출 성공");

		// 페이지 세팅
		Paging.setPage(svo);

		// 전체 레코드수 구현
		int total = managerSellerService.sellerListCnt(svo);
		log.info("total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(svo.getPage()) - 1) * Util.nvl(svo.getPageSize());
		log.info("count = " + count);

		List<SellerJoinVO> sellerList = managerSellerService.sellerList(svo);

		model.addAttribute("sellerList", sellerList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("s_data", svo);
		return "manager/main/sellerManage";
	}

	@RequestMapping(value = "/approval", method = RequestMethod.POST)
	public ModelAndView sellerApproval(@ModelAttribute("SellerJoinVO") SellerJoinVO svo, HttpSession session) {
		String setfrom = "blowhard736@gmail.com";
		String tomail = svo.getS_email(); // 받는 사람 이메일
		String title = "activillage입니다"; // 제목
		String content = "승인이 완료 되었습니다. 본 이메일로 정상 활동 할 수 있습니다. http://localhost:8080/ "; // 내용

		try {
			MimeMessage message = mailSender.createMimeMessage();
			MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");

			messageHelper.setFrom(setfrom); // 보내는사람 생략하거나 하면 정상작동을 안함
			messageHelper.setTo(tomail); // 받는사람 이메일
			messageHelper.setSubject(title); // 메일제목은 생략이 가능하다
			messageHelper.setText(content); // 메일 내용

			mailSender.send(message);
		} catch (Exception e) {
			System.out.println(e);
		}

		log.info("manager manager/retire 호출 성공");
		int result = 0;
		ModelAndView mav = new ModelAndView();
		result = managerSellerService.sellerApproval(svo);
		if (result == 1) {
			mav.setViewName("redirect:/manager/main/sellerManage.do");
			return mav;
		} else {
			mav.setViewName("/manager/main/sellerManage.do");
			return mav;
		}

	}

	// 사업자탈퇴
	@RequestMapping(value = "/sellerWithdrawal")
	public ModelAndView sellerWithdrawal(@ModelAttribute SellerJoinVO svo, HttpServletRequest request,
			HttpSession session) throws IOException {
		log.info("sellerWithdrawal 호출 성공");

		// 아래 변수에는 입력 성공에 대한 상태값 담습니다.(1 or 0)
		int result = 0;
		ModelAndView mav = new ModelAndView();
		result = managerSellerService.sellerWithdrawalManager(svo.getS_email());
		System.err.println("controller result:" + result);
		if (result == 1) {
			session.setAttribute("withCode", 1);
			mav.setViewName("redirect:/manager/main/sellerManage.do");
		} else if (result == 2) {
			session.setAttribute("withCode", 2);
			mav.setViewName("redirect:/manager/main/sellerManage.do");
		} 
		System.out.println("탈퇴결과:" + result);
		return mav;
	}

	@RequestMapping(value = "/main/salesManage", method = RequestMethod.GET)
	public String salesManage(@ModelAttribute SalesVO svo, BookVO bvo, Model model, HttpSession session,
			HttpServletRequest request) {
		log.info("manager salesManage 호출 성공");

		// 페이지 세팅
		Paging.setPage(svo);

		// 전체 레코드수 구현
		int total = managerSellerService.salesListCnt(svo);
		log.info("total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(svo.getPage()) - 1) * Util.nvl(svo.getPageSize());
		log.info("count = " + count);

		List<SalesVO> salesList = managerSellerService.salesList(svo);

		// 바차트
		String fileName = bvo.getKeyword().toString();
		List<BookVO> salesBarList = managerSellerService.salesBarList(bvo);
		ChartMake.managerBarChart(request, salesBarList, session, salesList, fileName);
		// 월 바차트
		System.out.println(bvo.getYear());
		String monthFileName = "";
		if (bvo.getYear() != null && !bvo.getYear().equals("")) {
			monthFileName = bvo.getKeyword().toString() + bvo.getYear();
			List<BookVO> salesMonthBarList = managerSellerService.salesMonthBarList(bvo);
			ChartMake.managerMonthBarChart(request, salesMonthBarList, session, salesList, monthFileName);
			model.addAttribute("changeBar", "Y");
		} else {
			model.addAttribute("changeBar", "N");
		}
		model.addAttribute("salesList", salesList);
		model.addAttribute("salesBarList", salesBarList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", svo);
		model.addAttribute("fileName", fileName);
		model.addAttribute("monthFileName", monthFileName);

		return "manager/main/salesManage";
	}

	@RequestMapping(value = "/sellerChart", method = RequestMethod.GET)
	public String sellerChart(@ModelAttribute SellerJoinVO svo, Model model, HttpServletRequest request) {
		// 연령데이터
		Map<String, Integer> userAgeList = managerSellerService.sellerAreaList();
		ChartMake.sellerPieChart(request, userAgeList);

		return "manager/main/sellerChart";
	}

	@RequestMapping(value = "/sellerChartDown", method = RequestMethod.GET)
	public void sellerChartDown(ModelMap model, HttpServletRequest request, HttpServletResponse response,
			HttpSession session) throws Exception {

		String dFile = "sellerPieChart.jpg";
		String upDir = session.getAttribute("upChartDir").toString();
		String path = upDir + File.separator + dFile;

		File file = new File(path);
		String userAgent = request.getHeader("User-Agent");
		boolean ie = userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("rv:11") > -1;
		String fileName = null;

		if (ie) {
			fileName = URLEncoder.encode(file.getName(), "utf-8");
		} else {
			fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1");
		}

		response.setContentType("application/octet-stream");
		response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\";");

		FileInputStream fis = new FileInputStream(file);
		BufferedInputStream bis = new BufferedInputStream(fis);
		ServletOutputStream so = response.getOutputStream();
		BufferedOutputStream bos = new BufferedOutputStream(so);

		byte[] data = new byte[2048];
		int input = 0;
		while ((input = bis.read(data)) != -1) {
			bos.write(data, 0, input);
			bos.flush();
		}

		if (bos != null)
			bos.close();
		if (bis != null)
			bis.close();
		if (so != null)
			so.close();
		if (fis != null)
			fis.close();
	}
}
