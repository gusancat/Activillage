package com.activillage.manager.seller.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.manager.sales.vo.SalesVO;
import com.activillage.seller.join.vo.SellerJoinVO;
import com.activillage.user.book.vo.BookVO;

@Repository
public class ManagerSellerDaoImpl implements ManagerSellerDao {

	@Autowired
	private SqlSession session;

	@Override
	public List<SellerJoinVO> sellerList(SellerJoinVO svo) {
		// TODO Auto-generated method stub
		return session.selectList("sellerList", svo);
	}

	@Override
	public int sellerWithdrawal(String s_email) {
		// TODO Auto-generated method stub
		return session.update("sellerWithdrawal", s_email);
	}

	@Override
	public int sellerWithdrawalManager(String s_email) {
		// TODO Auto-generated method stub
		return session.update("sellerWithdrawalManager", s_email);
	}

	@Override
	public int sellerListCnt(SellerJoinVO svo) {
		// TODO Auto-generated method stub
		return (Integer) session.selectOne("sellerListCnt", svo);
	}

	@Override
	public int sellerApproval(SellerJoinVO svo) {
		// TODO Auto-generated method stub
		return session.update("sellerApproval", svo);
	}

	@Override
	public Map<String, Integer> sellerAreaList() {
		// TODO Auto-generated method stub
		return session.selectMap("sellerAreaList", "");
	}

	@Override
	public List<SalesVO> salesList(SalesVO svo) {
		// TODO Auto-generated method stub
		return session.selectList("salesList");
	}

	@Override
	public int salesListCnt(SalesVO svo) {
		// TODO Auto-generated method stub
		return (Integer) session.selectOne("salesListCnt", svo);
	}

	@Override
	public List<BookVO> salesBarList(BookVO bvo) {
		// TODO Auto-generated method stub
		return session.selectList("salesBarList", bvo);
	}

	@Override
	public List<BookVO> salesMonthBarList(BookVO bvo) {
		// TODO Auto-generated method stub
		return session.selectList("salesMonthBarList", bvo);
	}

	@Override
	public List<SalesVO> sellerWithdrawalConfirm(String s_email) {
		// TODO Auto-generated method stub
		return session.selectList("sellerWithdrawalConfirm", s_email);
	}

}
