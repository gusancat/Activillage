package com.activillage.user.answer.dao;

import java.util.List;

import com.activillage.user.answer.vo.AnswerVO;

public interface AnswerDao {
	public List<AnswerVO> answerList(AnswerVO avo); // 문의답변 목록보기
	public int inquiryAnswerRegi(AnswerVO avo); //문의사항 답변등록
	public int inquiryAnswerDelete(int s_a_no);	//문의사항 답변삭제하기
	public AnswerVO answerDetail(AnswerVO avo); //문의사항 답변 상세보기
	public int inquiryallDelete(int s_q_no);
	public AnswerVO answerExist(int s_q_no);
}
