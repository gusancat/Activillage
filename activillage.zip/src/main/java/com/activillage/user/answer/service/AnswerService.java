package com.activillage.user.answer.service;

import java.util.List;

import com.activillage.user.answer.vo.AnswerVO;

public interface AnswerService {
	public List<AnswerVO> answerList(AnswerVO avo); // 문의답변 목록보기
	public int inquiryAnswerRegi(AnswerVO avo);	//문의답변 등록하기
	public int inquiryAnswerDelete(int s_a_no);		//문의사항 답변삭제하기
	public AnswerVO answerDetail(AnswerVO avo); //문의사항 상세보기
	public AnswerVO answerExist(int s_q_no);
}
