package com.activillage.user.answer.vo;

public class AnswerVO {
	private int s_a_no; // 답변 고유번호
	private int s_q_no; // 문의 고유번호
	private String s_a_content; // 답변 내용
	private String s_a_date; // 답변 날짜
	private int m_no; // 관리자 고유번호

	public int getS_a_no() {
		return s_a_no;
	}

	public void setS_a_no(int s_a_no) {
		this.s_a_no = s_a_no;
	}

	public int getS_q_no() {
		return s_q_no;
	}

	public void setS_q_no(int s_q_no) {
		this.s_q_no = s_q_no;
	}

	public String getS_a_content() {
		return s_a_content;
	}

	public void setS_a_content(String s_a_content) {
		this.s_a_content = s_a_content;
	}

	public String getS_a_date() {
		return s_a_date;
	}

	public void setS_a_date(String s_a_date) {
		this.s_a_date = s_a_date;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

}
