package com.activillage.user.goodslist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.activillage.common.page.Paging;
import com.activillage.common.util.Util;
import com.activillage.seller.goods.service.GoodsService;
import com.activillage.seller.goods.service.PackageService;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;
import com.activillage.user.ganswer.vo.GanswerVO;
import com.activillage.user.goodslist.vo.GoodsListVO;
import com.activillage.user.gquestion.service.GquestionService;
import com.activillage.user.gquestion.vo.GquestionVO;
import com.activillage.user.join.vo.UserJoinVO;
import com.activillage.user.review.service.ReviewService;
import com.activillage.user.review.vo.ReviewVO;

import lombok.extern.java.Log;

@Controller
@RequestMapping(value = "/goodslist")
@Log
public class GoodsListController {

	@Autowired
	private GoodsService goodsService;

	@Autowired
	private PackageService packageService;

	@Autowired
	private ReviewService reviewService;

	@Autowired
	private GquestionService gQuestionService;

	/* 상품 리스트 구현하기 */

	@RequestMapping(value = "/goodsList", method = RequestMethod.GET)
	public String goodsList(@ModelAttribute GoodsListVO gvo, Model model) {
		log.info("상품 리스트 호출 성공");

		gvo.setPageSize(5 + "");
		// 페이지 세팅
		Paging.setPage(gvo);

		// 전체 레코드수 구현
		int total = goodsService.mainGoodsListCnt(gvo);
		log.info("total = " + total);

		// 글번호 재설정
		int count = total - (Util.nvl(gvo.getPage()) - 1) * Util.nvl(gvo.getPageSize());
		log.info("count = " + count);

		List<GoodsListVO> goodsList = goodsService.goodsList(gvo);
		model.addAttribute("goodsList", goodsList);
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", gvo);
		log.info("gvo: " + gvo);
		log.info("model: " + model);

		return "goodslist/goodsList";
	}

	// 사용자 상품 상세 출력
	@RequestMapping(value = "/goodsDetail.do", method = RequestMethod.GET)
	public String goodsDetail(@ModelAttribute GoodsVO gvo, PackageVO pvo, UserJoinVO uvo, ReviewVO rvo, GquestionVO qvo,
			GanswerVO avo, Model model) {
		log.info("goodsDetail 호출 성공");

		// 12-31페이징 리뷰
		rvo.setPageSize(3 + "");
		Paging.setPage(rvo);
		System.out.println(rvo.getPageSize());
		// 리뷰 전체 레코드 수 구현
		int total = reviewService.reviewListCnt(rvo);
		System.out.println("리뷰 total = " + total);
		// 리뷰 번호 재설정
		int count = total - (Util.nvl(rvo.getPage()) - 1) * Util.nvl(rvo.getPageSize());
		// 12-31페이징 리뷰
		model.addAttribute("count", count);
		model.addAttribute("total", total);
		model.addAttribute("data", rvo);

		// 12-31페이징 상품문의
		// 상품 관련 질문 전체 레코드 수 구현
		gvo.setPageSizeQ(5 + "");
		Paging.setPageQ(qvo);
		System.out.println("상품테스트:" + qvo);
		int totalQ = gQuestionService.questionListCnt(qvo);
		System.out.println(qvo.getStart_rowQ()+"s");
		System.out.println(qvo.getEnd_rowQ()+"q");
		System.out.println("상품 질문 total = " + totalQ);

		// 상품 관련 질문 번호 재설정
		int countQ = totalQ - (Util.nvl(qvo.getPageQ()) - 1) * Util.nvl(qvo.getPageSizeQ());
		// 12-31페이징 상품문의
		model.addAttribute("countQ", countQ);
		model.addAttribute("totalQ", totalQ);
		model.addAttribute("dataQ", qvo);

		GoodsVO detail = new GoodsVO();
		detail = goodsService.goodsDetail(gvo);

		List<PackageVO> packageDetail = null;
		packageDetail = packageService.packageList(gvo.getG_no());

		List<ReviewVO> reviewList = null;
		reviewList = reviewService.reviewList(rvo);

		List<GquestionVO> questionList = null;
		questionList = gQuestionService.questionList(qvo);

		model.addAttribute("detail", detail);
		model.addAttribute("packageList", packageDetail);
		model.addAttribute("reviewList", reviewList);
		model.addAttribute("questionList", questionList);

		return "goodslist/goodsDetail";
	}

}
