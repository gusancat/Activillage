package com.activillage.user.review.vo;

import com.activillage.common.vo.CommonVO;

public class ReviewVO extends CommonVO{

	private int r_no = 0;
	private int g_no = 0;
	private String u_email = "";
	private String r_content = "";
	private double r_grade = 0;
	private String r_image = "";
	private String r_date = "";

	public int getR_no() {
		return r_no;
	}

	public void setR_no(int r_no) {
		this.r_no = r_no;
	}

	public int getG_no() {
		return g_no;
	}

	public void setG_no(int g_no) {
		this.g_no = g_no;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public String getR_content() {
		return r_content;
	}

	public void setR_content(String r_content) {
		this.r_content = r_content;
	}

	public double getR_grade() {
		return r_grade;
	}

	public void setR_grade(double r_grade) {
		this.r_grade = r_grade;
	}

	public String getR_image() {
		return r_image;
	}

	public void setR_image(String r_image) {
		this.r_image = r_image;
	}

	public String getR_date() {
		return r_date;
	}

	public void setR_date(String r_date) {
		this.r_date = r_date;
	}

}
