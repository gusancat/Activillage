package com.activillage.user.ganswer.service;

import java.util.List;

import com.activillage.user.ganswer.vo.GanswerVO;

public interface GanswerService {

	public List<GanswerVO> gAnswerList(int g_q_no);

	public void gAnswerWrite(GanswerVO avo);

	public int gAnswerDelete(int g_q_no);

	

}
