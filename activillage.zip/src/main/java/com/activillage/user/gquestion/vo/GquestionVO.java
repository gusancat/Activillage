package com.activillage.user.gquestion.vo;

import com.activillage.common.vo.CommonVO;

public class GquestionVO extends CommonVO {

	private int g_q_no = 0;
	private int g_no = 0;
	private String g_name = "";
	private String u_email = "";
	private String g_q_title = "";
	private String g_q_content = "";
	private String g_q_date = "";
	private int count = 0;

	public int getG_q_no() {
		return g_q_no;
	}

	public void setG_q_no(int g_q_no) {
		this.g_q_no = g_q_no;
	}

	public int getG_no() {
		return g_no;
	}

	public void setG_no(int g_no) {
		this.g_no = g_no;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getU_email() {
		return u_email;
	}

	public void setU_email(String u_email) {
		this.u_email = u_email;
	}

	public String getG_q_title() {
		return g_q_title;
	}

	public void setG_q_title(String g_q_title) {
		this.g_q_title = g_q_title;
	}

	public String getG_q_content() {
		return g_q_content;
	}

	public void setG_q_content(String g_q_content) {
		this.g_q_content = g_q_content;
	}

	public String getG_q_date() {
		return g_q_date;
	}

	public void setG_q_date(String g_q_date) {
		this.g_q_date = g_q_date;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
