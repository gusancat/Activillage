package com.activillage.user.gquestion.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.activillage.user.gquestion.vo.GquestionVO;

@Repository
public class GquestionDAOImpl {

	@Autowired
	private SqlSession session;

	public List<GquestionVO> questionList(GquestionVO qvo) {
		return session.selectList("questionList", qvo);
	}

	public void questionWrite(GquestionVO qvo) {
		session.insert("com.activillage.user.gquestion.dao.GquestionDAO.questionWrite", qvo);

	}

	public List<GquestionVO> questionDetail(GquestionVO qvo) {
		return session.selectList("questionDetail", qvo);
	}

	public GquestionVO gquesDetail(GquestionVO gvo) {
		return (GquestionVO) session.selectOne("gquesDetail", gvo);
	}

	public int questionListCnt(GquestionVO qvo) {
		return (Integer) session.selectOne("questionListCnt", qvo);
	}

	public int gQuestionDelete(int g_q_no) {
		return (Integer) session.delete("gQuestionDelete", g_q_no);
	}
}
