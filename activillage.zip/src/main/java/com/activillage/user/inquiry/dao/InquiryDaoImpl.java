package com.activillage.user.inquiry.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.activillage.user.answer.vo.AnswerVO;
import com.activillage.user.inquiry.vo.InquiryVO;

public class InquiryDaoImpl implements InquiryDao{
	
	@Autowired
	private SqlSession session;
	
	//목록보기
	@Override
	public List<InquiryVO> inquiryList(InquiryVO ivo) {
		return session.selectList("inquiryList", ivo);
	}
	//등록하기
	@Override
	public int inquiryRegi(InquiryVO ivo) {
		return session.insert("inquiryRegi", ivo);
	}
	
	//삭제하기
	@Override
	public int inquiryDelete(int s_q_no) {
		System.out.println(s_q_no + "dao");
		return session.delete("inquiryDelete", s_q_no);
	}
	//상세보기
	@Override
	public InquiryVO inquiryDetail(InquiryVO ivo) {
		return (InquiryVO)session.selectOne("inquiryDetail", ivo);
	}
	
	// 페이징
	@Override
	public int inquiryListCnt(InquiryVO ivo) {
		return (Integer) session.selectOne("inquiryListCnt", ivo);
	}
}
