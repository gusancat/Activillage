package com.activillage.user.notice.service;

import java.util.List;

import com.activillage.user.notice.vo.NoticeVO;

public interface NoticeService {
	public List<NoticeVO> noticeList(); // 공지사항 목록보기

	public int noticeRegi(NoticeVO nvo); // 공지사항 등록하기

	public NoticeVO noticeDetail(NoticeVO nvo);

	public int noticeUpdate(NoticeVO nvo);

	public int noticeDelete(int n_no);
}
