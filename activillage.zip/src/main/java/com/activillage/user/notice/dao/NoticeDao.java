package com.activillage.user.notice.dao;

import java.util.List;

import com.activillage.user.notice.vo.NoticeVO;

public interface NoticeDao {
	public List<NoticeVO> noticeList(); // 공지사항 목록보기
	public int noticeRegi(NoticeVO nvo); // 공지사항 등록하기
	public NoticeVO noticeDetail(NoticeVO nvo);//수정용 상세보기
	public int noticeUpdate(NoticeVO nvo);// 수정
	public int noticeDelete(int n_no);
}
