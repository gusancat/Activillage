package com.activillage.seller.goods.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.activillage.seller.goods.dao.PackageDao;
import com.activillage.seller.goods.vo.GoodsVO;
import com.activillage.seller.goods.vo.PackageVO;

import lombok.extern.java.Log;


@Service
@Transactional
@Log
public class PackageServiceImpl implements PackageService {

	@Autowired
	private PackageDao packageDao;
	
	//패키지관리 페이지 불러오기
	@Override
	public GoodsVO packageManager(GoodsVO gvo) {
		GoodsVO detail = null;
		detail = packageDao.packageManager(gvo);
		
		return detail;
	}
	

	//패키지 목록 구현
	@Override
	public List<PackageVO> packageList(Integer g_no) {
		List<PackageVO> myList = null;
		myList = packageDao.packageList(g_no);
		return myList;
	}

	//패키지 등록
	@Override
	public int packageRegiste(PackageVO pvo) {
		
		int result = 0;
		
		try {
			result = packageDao.packageRegiste(pvo);
		}catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}
		
		return result;
	}


	//패키지 삭제
	@Override
	public int packageDelete(int p_no) {
		
		int result = 0;
		
		try {
			result = packageDao.packageDelete(p_no);
		}catch(Exception e) {
			e.printStackTrace();
			result = 0;
		}

		return result;
	}

	//패키지 체크
	@Override
	public int packageCheck(int g_no) {
		
		int result;
		
		if(packageDao.packageMinSelect(g_no)!=null) {
			result = 1;
		}else {
			result = 2;
		}
		
		return result;
	}

	//최소값 불러오기
	@Override
	public PackageVO packageMinPrice(PackageVO pvo, int g_no) {
		
		PackageVO min_price = null;
		
		min_price=packageDao.packageMinSelect(g_no);
		
		return min_price;
	}
	
	//패키지 내용 불러오기
		@Override
		public PackageVO packageSelect(Integer p_no) {
			
			PackageVO choicePackage = null;
			choicePackage = packageDao.packageSelect(p_no);
			
			return choicePackage;
		}


}
