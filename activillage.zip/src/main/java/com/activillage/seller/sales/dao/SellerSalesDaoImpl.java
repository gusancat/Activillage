package com.activillage.seller.sales.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;

import com.activillage.seller.sales.vo.SellerSalesVO;

public class SellerSalesDaoImpl implements SellerSalesDao {

	@Autowired
	private SqlSession session;

	@Override
	public int sellerSalesCnt(SellerSalesVO svo) {
		return (Integer) session.selectOne("sellerSalesCnt");
	}

	@Override
	public List<SellerSalesVO> sellerSalesList(SellerSalesVO svo) {
		return session.selectList("sellerSalesList", svo);
	}

	@Override
	public String sellerSalesTotal(SellerSalesVO svo) {
		return session.selectOne("sellerSalesTotal");
	}

}
