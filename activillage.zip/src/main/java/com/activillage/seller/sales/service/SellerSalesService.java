package com.activillage.seller.sales.service;

import java.util.List;

import com.activillage.seller.sales.vo.SellerSalesVO;

public interface SellerSalesService {
	
	public int sellerSalesCnt(SellerSalesVO svo);
	
	public List<SellerSalesVO> sellerSalesList(SellerSalesVO svo);
	
	public String sellerSalesTotal(SellerSalesVO svo);

}
