package com.activillage.common.file;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import org.imgscalr.Scalr;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.java.Log;

@Log
public class FileUploadUtil {

	//파일 업로드할 폴더 생성
	public static void makeDir(String docRoot) {
		File fileDir = new File(docRoot);
		if(fileDir.exists()) {
			return;
		}
		fileDir.mkdirs();
	}
	
	//파일 업로드 메소드
	public static String fileUpload(MultipartFile file, HttpServletRequest request,
			String fileName) throws IOException{
		log.info("fileUpload 호출 성공");
		
		String real_name = null;
		String org_name = file.getOriginalFilename();
		log.info("org_name:"+org_name);
		
		//파일명 변경
		if(org_name != null && (!org_name.equals(""))) {
			real_name = fileName+"_"+System.currentTimeMillis()+"_"+org_name;
			
			String docRoot = request.getSession().getServletContext()
					.getRealPath("/uploadStorage/"+fileName);
			makeDir(docRoot);
			
			File fileAdd = new File(docRoot+"/"+real_name);
			log.info("업로드할 파일(fileAdd):"+fileAdd);
			
			file.transferTo(fileAdd);
		}
		return real_name;
	}
	
	//파일 삭제
	public static void fileDelete(String fileName, HttpServletRequest request)
	throws IOException{
		log.info("fileDelete 호출 성공");
		boolean result = false;
		
		String dirName = fileName.substring(0, fileName.indexOf("_"));
		String docRoot = request.getSession().getServletContext().getRealPath(
				"/uploadStorage/"+dirName);
		
		File filedelete = new File(docRoot+"/"+fileName);
		log.info("삭제할 파일(fileDelete):"+filedelete);
		if(filedelete.exists()&&filedelete.isFile()) {
			result = filedelete.delete();
		}
		
		//폴더 전체 삭제
		/*File deleteFolder = new File(docRoot);
		if(deleteFolder.exists()) {
			File[] deleteFolderList = deleteFolder.listFiles();
			
			for ( int j = 0; j< deleteFolderList.length; j++) {
				deleteFolderList[j].delete();
			}
			
			if(deleteFolderList.length==0&&deleteFolder.isDirectory()) {
				result = deleteFolder.delete();
			}
		}*/
		
		log.info("파일 삭제 여부:"+result);
	}
	
	
	//파일 썸네일 생성
	public static String makeThumbnail(String fileName, HttpServletRequest request)
	throws Exception{
		String dirName = fileName.substring(0, fileName.indexOf("_"));
		//이미지가 존재하는 폴더 추출
		String imgPath
		= request.getSession().getServletContext().getRealPath("/uploadStorage/"+dirName);
		//추출된 폴더의 실제 경로
		File fileAdd = new File(imgPath, fileName);
		log.info("원본 이미지 파일(fileAdd):"+fileAdd);
		
		
		//리사이즈
		BufferedImage sourceImg = ImageIO.read(fileAdd);
		
		//썸네일 너비와 높이
		int dw= 230;
		int dh = 149;
				
		//원본이미지의 너비와 높이
		int ow = sourceImg.getWidth();
		int oh = sourceImg.getHeight();
		
		//원본 너비 기준으로 썸네일 비율로 높이 계산
		int nw = ow;
		int nh = (ow*dh)/dw;
		
		//원본이미지 가운데서 크롭
		//BufferedImage cropImg = Scalr.crop(sourceImg, (ow-nw)/2, (oh-nh)/2, nw,nh);
		
		BufferedImage destImg = Scalr.resize(sourceImg, dw, dh);

		
		String thumbnailName = dirName+"_thumbnail_"+fileName;
		
		File newFile = new File(imgPath,thumbnailName);
		log.info("업로드할 파일(newFile):"+newFile);
		
		String formatName = fileName.substring(fileName.lastIndexOf(".")+1);
		log.info("확장자(formatName):"+formatName);
		
		ImageIO.write(destImg, formatName, newFile);
		return thumbnailName;
	}
	
}
