package com.activillage.common.vo;

public class CommonVO {
	private String page; // 페이지 번호
	private String pageSize; // 페이지에 보여주는 줄수
	private String start_row;// 시작 레코드 번호
	private String end_row; // 종료 레코드 번호
	
	//상품문의 페이지용 필드
	private String pageQ; // 페이지 번호
	private String pageSizeQ; // 페이지에 보여주는 줄수
	private String start_rowQ;// 시작 레코드 번호
	private String end_rowQ; // 종료 레코드 번호

	// 조건 검색 시 사용할 필드
	private String search_name = "";
	private String search_keyword = "";

	// 조건검색시 사용할 필드
	private String search = "";
	private String keyword = "";

	// 제목 클릭시 정렬을 위한 필드
	private String start_date = "";
	private String end_date = "";

	// 클라이언트에게 코드나 결과 내용을 위한 필드
	private String order_by;
	private String order_sc;

	private String result_cd;
	private String result_msg;
	
	private String year;

	
	
	
	
	public String getPageQ() {
		return pageQ;
	}

	public void setPageQ(String pageQ) {
		this.pageQ = pageQ;
	}

	public String getPageSizeQ() {
		return pageSizeQ;
	}

	public void setPageSizeQ(String pageSizeQ) {
		this.pageSizeQ = pageSizeQ;
	}

	public String getStart_rowQ() {
		return start_rowQ;
	}

	public void setStart_rowQ(String start_rowQ) {
		this.start_rowQ = start_rowQ;
	}

	public String getEnd_rowQ() {
		return end_rowQ;
	}

	public void setEnd_rowQ(String end_rowQ) {
		this.end_rowQ = end_rowQ;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getSearch_name() {
		return search_name;
	}

	public void setSearch_name(String search_name) {
		this.search_name = search_name;
	}

	public String getSearch_keyword() {
		return search_keyword;
	}

	public void setSearch_keyword(String search_keyword) {
		this.search_keyword = search_keyword;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getPageSize() {
		return pageSize;
	}

	public void setPageSize(String pageSize) {
		this.pageSize = pageSize;
	}

	public String getStart_row() {
		return start_row;
	}

	public void setStart_row(String start_row) {
		this.start_row = start_row;
	}

	public String getEnd_row() {
		return end_row;
	}

	public void setEnd_row(String end_row) {
		this.end_row = end_row;
	}

	public String getSearch() {
		return search;
	}

	public void setSearch(String search) {
		this.search = search;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public String getEnd_date() {
		return end_date;
	}

	public void setEnd_date(String end_date) {
		this.end_date = end_date;
	}

	public String getOrder_by() {
		return order_by;
	}

	public void setOrder_by(String order_by) {
		this.order_by = order_by;
	}

	public String getOrder_sc() {
		return order_sc;
	}

	public void setOrder_sc(String order_sc) {
		this.order_sc = order_sc;
	}

	public String getResult_cd() {
		return result_cd;
	}

	public void setResult_cd(String result_cd) {
		this.result_cd = result_cd;
	}

	public String getResult_msg() {
		return result_msg;
	}

	public void setResult_msg(String result_msg) {
		this.result_msg = result_msg;
	}
}